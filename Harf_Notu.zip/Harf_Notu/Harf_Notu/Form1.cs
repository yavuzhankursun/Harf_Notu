using System.Xml;

namespace Harf_Notu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            double not;
            not = double.Parse(mtxtBoxNot.Text);
            if(not <= 100 && not >= 90)
            {
                btnSonuc.Text = "Ge�tiniz  Notunuz : AA";
            }
            else if (not <= 89.99 && not >= 88.33)
            {
                btnSonuc.Text = "Ge�tiniz  Notunuz : BA";
            }
            else if (not <= 88.32 && not >= 76.66)
            {
                btnSonuc.Text = "Ge�tiniz  Notunuz : BB";
            }
            else if (not <= 76.65 && not >= 65.23)
            {
                btnSonuc.Text = "Ge�tiniz  Notunuz : CB";
            }
            else if (not <= 65.22 && not >= 53.33)
            {
                btnSonuc.Text = "Kald�n�z  Notunuz : CC";
            }
            else if (not <= 52.32 && not >= 41.66)
            {
                btnSonuc.Text = "Kald�n�z  Notunuz : DC";
            }
            else if(not <= 41.65 && not >= 31)
            {
                btnSonuc.Text = "Kald�n�z  Notunuz : DD";
            }
            else if (not <= 30 && not >= 21)
            {
                btnSonuc.Text = "Kald�n�z  Notunuz : FD";
            }
            else if (not <= 20 && not >= 0)
            {
                btnSonuc.Text = "Kald�n�z Notunuz : FF";
            }
        }
    }
}