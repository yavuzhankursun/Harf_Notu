﻿namespace Harf_Notu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNot = new System.Windows.Forms.Label();
            this.mtxtBoxNot = new System.Windows.Forms.MaskedTextBox();
            this.lblKarsilik = new System.Windows.Forms.Label();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.btnSonuc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNot
            // 
            this.lblNot.AutoSize = true;
            this.lblNot.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblNot.Location = new System.Drawing.Point(80, 98);
            this.lblNot.Name = "lblNot";
            this.lblNot.Size = new System.Drawing.Size(191, 23);
            this.lblNot.TabIndex = 0;
            this.lblNot.Text = "Not Aralığınızı Seçiniz :";
            // 
            // mtxtBoxNot
            // 
            this.mtxtBoxNot.Location = new System.Drawing.Point(277, 97);
            this.mtxtBoxNot.Name = "mtxtBoxNot";
            this.mtxtBoxNot.Size = new System.Drawing.Size(208, 27);
            this.mtxtBoxNot.TabIndex = 1;
            // 
            // lblKarsilik
            // 
            this.lblKarsilik.AutoSize = true;
            this.lblKarsilik.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblKarsilik.Location = new System.Drawing.Point(105, 315);
            this.lblKarsilik.Name = "lblKarsilik";
            this.lblKarsilik.Size = new System.Drawing.Size(166, 23);
            this.lblKarsilik.TabIndex = 2;
            this.lblKarsilik.Text = "Harf Notu Karşılığı :";
            // 
            // btnHesapla
            // 
            this.btnHesapla.Location = new System.Drawing.Point(356, 159);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(129, 63);
            this.btnHesapla.TabIndex = 3;
            this.btnHesapla.Text = "Hesapla";
            this.btnHesapla.UseVisualStyleBackColor = true;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // btnSonuc
            // 
            this.btnSonuc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSonuc.Location = new System.Drawing.Point(300, 266);
            this.btnSonuc.Name = "btnSonuc";
            this.btnSonuc.Size = new System.Drawing.Size(223, 123);
            this.btnSonuc.TabIndex = 4;
            this.btnSonuc.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 480);
            this.Controls.Add(this.btnSonuc);
            this.Controls.Add(this.btnHesapla);
            this.Controls.Add(this.lblKarsilik);
            this.Controls.Add(this.mtxtBoxNot);
            this.Controls.Add(this.lblNot);
            this.Name = "Form1";
            this.Text = "Harf Notu Dönüştürücü";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblNot;
        private MaskedTextBox mtxtBoxNot;
        private Label lblKarsilik;
        private Button btnHesapla;
        private Button btnSonuc;
    }
}